1 delete and update
2 null
3 AUTO_INCREMENT and DEFAULT
4 Value cop ANY
5 VALUE in SubQuery
6 Value cop ALL
7 calculate
8 boolean
9 group by
10 alias
11 having and order by
12 distinct